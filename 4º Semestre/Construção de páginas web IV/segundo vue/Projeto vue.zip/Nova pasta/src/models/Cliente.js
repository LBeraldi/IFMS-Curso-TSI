export default class Cliente{
    constructor(){
        thi.id="";
        thi.nome="";
        thi.email="";
        thi.telefone=""
    }
}