export default class Cliente{
    constructor(){
        this.id="";
        this.nome="";
        this.email="";
        this.telefone="";
    }
}