<template>
    <div v-for="c in campos" :key="c">
        <label>{{ c.label }}</label>
        <input v-model="objeto[c.chave]"/>
    </div>
    <button v-on:click="acaoBotaoSalvar">Salvar</button>
    <button v-on:click="acaoBotaoCancelar">Cancelar</button>
</template>

<script>
    export default{
        emits:["onSalvar","onCancelar"],
        props:["campos","objeto"],
        methods:{
            acaoBotaoSalvar(){
                this.$emit("onSalvar","Evento Disparado");
            },
            acaoBotaoCancelar(){
                this.$emit("onCancelar");    
            }
        }
    }
</script>

<style>

</style>