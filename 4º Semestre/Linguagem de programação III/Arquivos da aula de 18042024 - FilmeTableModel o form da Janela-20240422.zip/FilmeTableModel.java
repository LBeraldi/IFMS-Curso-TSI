/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javabd;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author renato
 */
public class FilmeTableModel extends AbstractTableModel {
    private String[] nomeColunas = {"Código", "Título", "Gênero"};
    private List<Filme> filmes = null;

    public FilmeTableModel() {
//        FilmesDAO fdao = new FilmesDAO();
//        filmes = fdao.consultar();
        filmes = new FilmesDAO().consultar();
    }
    
    @Override
    public int getRowCount() {
        return filmes.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public String getColumnName(int coluna) {
        return nomeColunas[coluna];
    }
    
    @Override
    public Object getValueAt(int linha, int coluna) {
        switch (coluna) {
            case 0: return filmes.get(linha).getCodigo();
            case 1: return filmes.get(linha).getTitulo();
            case 2: return filmes.get(linha).getGenero();
        }
        return null;
    }
    
    public void addFilme(Filme filme) {
        filmes.add(filme);
        this.fireTableDataChanged();
    }
    
    public void excluirFilme(int linha) {
        filmes.remove(linha);
        this.fireTableRowsDeleted(linha, linha);
    }
 }
