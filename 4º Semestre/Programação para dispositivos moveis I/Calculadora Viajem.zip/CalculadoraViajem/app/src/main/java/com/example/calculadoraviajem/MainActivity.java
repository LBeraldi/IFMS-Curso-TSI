package com.example.calculadoraviajem;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class MainActivity extends AppCompatActivity {
    private static final String TITLE = "Calculadora de viajem.";
    private EditText editTextDistance;
    private EditText editTextConsumption;
    private EditText editTextFuelPrice;
    private TextView textViewTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle(TITLE);
        editTextDistance = findViewById(R.id.editTextDistance);
        editTextConsumption = findViewById(R.id.editTextConsumption);
        editTextFuelPrice = findViewById(R.id.editTextFuelPrice);
        textViewTotal = findViewById(R.id.textViewTotal);
    }

    public void calcularViajem(View view){
        BigDecimal distance = new BigDecimal(editTextDistance.getText().toString());
        BigDecimal consumption = new BigDecimal(editTextConsumption.getText().toString());
        BigDecimal fuelPrice = new BigDecimal(editTextFuelPrice.getText().toString());
        BigDecimal total = distance.divide(consumption,2,RoundingMode.HALF_UP).multiply(fuelPrice);
        textViewTotal.setText(total.setScale(2,BigDecimal.ROUND_HALF_UP).toString());

    }
}