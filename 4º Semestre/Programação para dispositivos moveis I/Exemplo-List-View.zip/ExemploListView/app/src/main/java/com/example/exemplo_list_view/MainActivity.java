package com.example.exemplo_list_view;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.os.Bundle;
import java.util.ArrayList;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
   private ArrayList<String> nomes;
    private ListView listViewNome;
    private ArrayAdapter adapter;

    private TextView textViewEntrada;
    public void entrarCarro(View view){
        listViewNome = findViewById(R.id.textViewEntrada);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nomes = new ArrayList<String>();

    adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, nomes);
    listViewNome.setAdapter(adapter);
    }
}