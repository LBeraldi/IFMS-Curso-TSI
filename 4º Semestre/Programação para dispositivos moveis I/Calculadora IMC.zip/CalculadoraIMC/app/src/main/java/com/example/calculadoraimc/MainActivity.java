package com.example.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;


public class MainActivity extends AppCompatActivity {
    private static final String TITLE = "Calculadora IMC.";
    private EditText editTextPeso;
    private EditText editTextAltura;
    private TextView textViewIMC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle(TITLE);
        editTextPeso = findViewById(R.id.editTextPeso);
        editTextAltura = findViewById(R.id.editTextAltura);
        textViewIMC = findViewById(R.id.textViewIMC);
    }

    public void calcularIMC(View view) {
        BigDecimal peso = new BigDecimal(editTextPeso.getText().toString());
        BigDecimal altura = new BigDecimal(editTextAltura.getText().toString());
        BigDecimal total = peso.divide(altura.pow(2),RoundingMode.HALF_UP);
        textViewIMC.setText(total.setScale(2,RoundingMode.HALF_UP).toString());
    }


}